package schwartz.PEOPLE;

import java.io.Serializable;
import java.util.ArrayList;

import schwartz.COURSES.Courses;

public class Student extends User implements Serializable{
	
	private ArrayList<Courses> studsCourses = new ArrayList<Courses>();
	
	public Student(String username, String password, String firstName, String lastName) {
		super(username, password, firstName, lastName);
		this.studsCourses = new ArrayList<Courses>();
	}
	
	//calls the User view all courses method
	public Object[][] viewAllCourses() {
		return super.viewAllCourses();
	}
	
	public Object[][] viewFullCourses() {
		System.out.println("Viewing all courses that are not full: ");
		ArrayList<Courses> nalc = new ArrayList<Courses>();
		for(Courses c : super.getCourse()) {
			if(c.getNumRegStudents() < c.getMaxStudents()) {
				nalc.add(c);
			}
		}
		Object[][] course = new Object[nalc.size()][5];
		int i = 0;
		for(Courses c : nalc) {
			course[i][0] = c.getCourseName();
			course[i][1] = c.getCourseID();
			course[i][2] = c.getNumRegStudents();
			course[i][3] = c.getInstructor();
			course[i][4] = c.getCourseNum();
			i++;
		}
		return course;
	}
	
	//registers this student on the course
	//data validation
	public boolean registerOnCourse(String courseName, String courseID, int cNum, String fname, String lname) {
	
		String name = fname + " " + lname;
		for(int i = 0; i < super.getCourse().size(); i++) {
			if(super.getCourse().get(i).getCourseID().equals(courseID)) {
				if(super.getCourse().get(i).getCourseNum() == cNum) {
					Student s = null;
					if(super.getCourse().get(i).getNumRegStudents() < super.getCourse().get(i).getMaxStudents()) {
						boolean tf = false;
						for(int j = 0; j < super.getStudent().size(); j++) {
							if(name.equals(super.getStudent().get(j).getFirstName() + " " + super.getStudent().get(j).getLastName())){
								tf = true;
								s = super.getStudent().get(j);
								if(!courseName.equals(super.getCourse().get(i).getCourseName())) {
									break;
								}
								if(tf) {
									for(int z = 0; z < super.getCourse().get(i).getNumRegStudents(); z++) {
										if(name.equals(super.getCourse().get(i).getStudInCourse().get(z).getFirstName() + " " + super.getCourse().get(i).getStudInCourse().get(z).getLastName())){
											tf = false;
											System.out.println(super.getCourse().get(i).getStudInCourse().get(z).getFirstName() + " " + super.getCourse().get(i).getStudInCourse().get(z).getLastName() + " is already registered for the course\n");
											break;
										}
									}	
								}
								if(tf) {
									super.getCourse().get(i).getStudInCourse().add(s);		
									s.getStudsCourses().add(super.getCourse().get(i));
									System.out.println(name + " is now registered on " + super.getCourse().get(i).getCourseName() + "\n");
									return true;
								}	
							}
						}	
					}
				}
			}	
		}
		return false;
	}
	
	//withdraws a student from a course
	//data validation
	public boolean withdrawFromCourse(String courseName, String courseID, int cNum, String fname, String lname) {
		if(this.getStudsCourses().size() == 0) {
			return false;
			
		}
		else {
			String name = fname + " " + lname;
			for(int i = 0; i < super.getCourse().size(); i++) {
				if(super.getCourse().get(i).getCourseID().equals(courseID)) {
					if(super.getCourse().get(i).getCourseNum() == cNum) {
						Courses course = super.getCourse().get(i);
						for(int j = 0; j < super.getStudent().size(); j++) {
							if(name.equals(super.getStudent().get(j).getFirstName() + " " + super.getStudent().get(j).getLastName())){
								super.getStudent().get(j).getStudsCourses().remove(course);
								break;
							}
						}
						//adds the rest of the students back to the student list for that specific course
						ArrayList<Student> sc = new ArrayList<Student>();
						int size = course.getNumRegStudents();
						course.setStudInCourse(sc);
						int added = 0;
						loop: for(int g = 0; g < super.getStudent().size(); g++) {
							Student p = super.getStudent().get(g);
							for(int k = 0; k < p.getStudsCourses().size(); k++) {
								Courses c = p.getStudsCourses().get(k);
								if((course.getCourseID()).equals(c.getCourseID()) && (course.getCourseNum() == c.getCourseNum())) {
									course.getStudInCourse().add(p);
									added++;
								}
								if(added == size-1) {
									break loop;
								}
							}
						}
					}
				}
			}
			System.out.print("\n");
		}
		return true;
	}
	
	//view the courses this student is registered in
	public Object[][] viewMyCourses() {
		
		Object[][] course = new Object[this.getStudsCourses().size()][5];
		int k = 0;
		for(Courses c : this.getStudsCourses()) {
			course[k][0] = c.getCourseName();
			course[k][1] = c.getCourseID();
			course[k][2] = c.getNumRegStudents();
			course[k][3] = c.getInstructor();
			course[k][4] = c.getCourseNum();
			k++;
		}
		return course;
	
	}
	
	//calls the superclass exit method and serializes the program
	public void exit() {
		super.exit();
	}
	
	
	//getters and setters
	public ArrayList<Courses> getStudsCourses() {
		return studsCourses;
	}

	public void setStudsCourses(ArrayList<Courses> studsCourses) {
		this.studsCourses = studsCourses;
	}
	
	
}