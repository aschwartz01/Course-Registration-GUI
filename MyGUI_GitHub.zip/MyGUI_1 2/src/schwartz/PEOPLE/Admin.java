package schwartz.PEOPLE;

import java.io.*;
import java.util.*;
import schwartz.COURSES.*;
import schwartz.INTERFACES.AdminMethods;


public class Admin extends User implements AdminMethods, Serializable, Comparable<Courses>{

	public Admin(String firstName, String lastName) {
		super("Admin", "Admin001", firstName, lastName);
	}
	
	//Adds a new course and then adds it to the course list
	public void createNew(String className, String cID, int maxStuds, String instructor, int cNum, String cLoc) {
		Courses c = new Courses(className, cID, maxStuds, 0, null, instructor, cNum, cLoc);
		super.getCourse().add(c);
		System.out.println(className + " with " + instructor + " has been added to the system\n");
	}
	
	@Override // creates a new student
	public void createNew(String username, String password, String firstName, String lastName) {
		Student s = new Student(username, password, firstName, lastName);
		super.getStudent().add(s);
		System.out.println("New student " + firstName + " " + lastName + " added\n");
	}
	
	//calls the User view all courses method
	public Object[][] viewAllCourses() {
		return super.viewAllCourses(); 
	}

	
	
	@Override //Will this work for the students already in the course? What will happen to them??
	// setting new values or adding/subtracting from them?
	public String editCourse(String courseID, int cnum, String answer, String input, String edit) {
		int q = 0;
		loop: for(int i = 0; i < super.getCourse().size(); i++) {
			if(this.getCourse().get(i).getCourseID().equals(courseID)) {
				if(this.getCourse().get(i).getCourseNum() == cnum) {
					q++;
					while(true) {
						switch (answer) {
						case "max":// edit the maximum number of students in the course
							int max = Integer.parseInt(input);
							if(max < this.getCourse().get(i).getNumRegStudents()) {
								return "Maximum students in a course must be greater than students registered";
							}
							else {
								this.getCourse().get(i).setMaxStudents(max);
								return "New maximum number of students for " + this.getCourse().get(i).getCourseName() + ": " + max;
							}
							
						case "registered"://Remove or add
							if(edit.equals("add")) {
								String aName = this.getCourse().get(i).getCourseName();
								String[] names = input.split("-");
								String aFname = names[0];
								String aLname = names[1];
								int aNum = cnum;
								boolean tf = this.registerOnCourse(aName, courseID, aFname, aLname, aNum);
								if(tf) {
									return aFname + " " + aLname + " is now registered on " + this.getCourse().get(i).getCourseName();
								}
								return "Could not register on course";
								
							}
							else if(edit.equals("remove")) {
								String cName = this.getCourse().get(i).getCourseName();
								System.out.println(input);
								String[] names = input.split("-");
								String rFname = names[0];
								String rLname = names[1];
								boolean tf = this.withdrawFromCourse(cName, courseID, rFname, rLname, cnum);
								if(tf) {
									return rFname + " " + rLname + " has been withdrawn from " + this.getCourse().get(i).getCourseName();
								}
								return "Could not withdraw " + rFname + " " + rLname + " from " + this.getCourse().get(i).getCourseName();
								
							}
							
						case "instructor"://change the instructor
							String inst = input;
							this.getCourse().get(i).setInstructor(inst);
							return input + " is the new instructor for " + this.getCourse().get(i).getCourseName();
							
						case "location"://change the location of the course
							String loc = input;
							this.getCourse().get(i).setCourseLoc(loc);
							return loc + " is the new location for " + this.getCourse().get(i).getCourseName();
							
						
						}
						
					}
				}
			}
		}
		
		return "Course not found";
		
	}
	
	//registers this student on the course
	//data validation
	public boolean registerOnCourse(String courseName, String courseID, String fname, String lname, int courseNum) {
		String name = fname + " " + lname;
		for(int i = 0; i < super.getCourse().size(); i++) {
			if(super.getCourse().get(i).getCourseID().equals(courseID)) {
				if(super.getCourse().get(i).getCourseNum() == courseNum) {
					Student s = null;
					if(super.getCourse().get(i).getNumRegStudents() < super.getCourse().get(i).getMaxStudents()) {
						boolean tf = false;
						
						for(int j = 0; j < super.getStudent().size(); j++) {
							if(name.equals(super.getStudent().get(j).getFirstName() + " " + super.getStudent().get(j).getLastName())){
								tf = true;
								s = super.getStudent().get(j);
								if(!courseName.equals(super.getCourse().get(i).getCourseName())) {
									break;
								}
								if(tf) {
									for(int z = 0; z < super.getCourse().get(i).getNumRegStudents(); z++) {
										if(name.equals(super.getCourse().get(i).getStudInCourse().get(z).getFirstName() + " " + super.getCourse().get(i).getStudInCourse().get(z).getLastName())){
											tf = false;
											System.out.println(super.getCourse().get(i).getStudInCourse().get(z).getFirstName() + " " + super.getCourse().get(i).getStudInCourse().get(z).getLastName() + " is already registered for the course\n");
											break;
										}
									}	
								}
								if(tf) {
									super.getCourse().get(i).getStudInCourse().add(s);		
									s.getStudsCourses().add(super.getCourse().get(i));
									
									
									System.out.println(name + " is now registered on " + super.getCourse().get(i).getCourseName() + "\n");
									return true;
								}
								
							}
						}	
					}
				}
			}	
		}
		return false;
	}
	
	//withdraws a student from a course
	//data validation
	public boolean withdrawFromCourse(String courseName, String courseID, String fname, String lname, int cnum) {
		int cNum = cnum;
		String name = fname + " " + lname;
		boolean tf1 = false;
		boolean tf2 = false;
		for(int i = 0; i < super.getCourse().size(); i++) {
			if(super.getCourse().get(i).getCourseID().equals(courseID)) {
				if(super.getCourse().get(i).getCourseNum() == cNum) {
					Courses course = super.getCourse().get(i);
					for(int j = 0; j < super.getStudent().size(); j++) {
						if(name.equals(super.getStudent().get(j).getFirstName() + " " + super.getStudent().get(j).getLastName())){
							super.getStudent().get(j).getStudsCourses().remove(course);
							System.out.println("Withdrawn from: " + course.getCourseName() + "\n");
							tf1 = true;
							break;
						}
					}
					//adds the rest of the students back to the student list for that specific course
					ArrayList<Student> sc = new ArrayList<Student>();
					int size = course.getNumRegStudents();
					course.setStudInCourse(sc);
					int added = 0;
					loop: for(int g = 0; g < super.getStudent().size(); g++) {
						Student p = super.getStudent().get(g);
						for(int k = 0; k < p.getStudsCourses().size(); k++) {
							Courses c = p.getStudsCourses().get(k);
							if((course.getCourseID()).equals(c.getCourseID()) && (course.getCourseNum() == c.getCourseNum())) {
								course.getStudInCourse().add(p);
								added++;
								tf2 = true;
								
							}
							if(added == size-1) {
								break loop;
							}
						}
					}
				}
			}
			
		}
		if(tf1 == true && tf2 == true) {
			return true;
		}
		else {
			return false;
		}
		
	}
	

	@Override //displays the information for each the course that matches the courseID
	public Object[][] displayCourseInfo(String courseID, int cNum) {
		String studs = ""; 
		Object[][] data = new Object[8][2];
		for(int i = 0; i < super.getCourse().size(); i++) {
			if(super.getCourse().get(i).getCourseID().equals(courseID)) {
				if(super.getCourse().get(i).getCourseNum() == cNum) {
					
					data[0][0] = "Course Name";
					data[0][1] = super.getCourse().get(i).getCourseName();
					data[1][0] = "Course ID";
					data[1][1] = super.getCourse().get(i).getCourseID();
					
					data[2][0] = "Maximum Students";
					data[2][1] = super.getCourse().get(i).getMaxStudents();
					
					data[3][0] = "# of Students";
					data[3][1] = super.getCourse().get(i).getNumRegStudents();
					
					if(super.getCourse().get(i).getStudInCourse().size() == 0) {
						studs = "none";
					}
					else {
						//data validation for printing purposes
						//formats the students names in the students in course ArrayList
						for(int j = 0; j < super.getCourse().get(i).getStudInCourse().size(); j++) {
							if(super.getCourse().get(i).getStudInCourse().size() == j+1) {
								studs += super.getCourse().get(i).getStudInCourse().get(j).getLastName() + "," + super.getCourse().get(i).getStudInCourse().get(j).getFirstName();
							}
							else {
								studs += super.getCourse().get(i).getStudInCourse().get(j).getLastName() + "," + super.getCourse().get(i).getStudInCourse().get(j).getFirstName() + "; ";
							}	
						}
					}
					data[4][0] = "Students in Course";
					data[4][1] = studs;
					
					data[5][0] = "Instructor";
					data[5][1] = super.getCourse().get(i).getInstructor();
					
					data[6][0] = "Course Number";
					data[6][1] = super.getCourse().get(i).getCourseNum();
					
					data[7][0] = "Course Location";
					data[7][1] = super.getCourse().get(i).getCourseLoc();
					
				}
			}			
		}	
		
		return data;
	}
	
	@Override //deletes the course from both the student's course arrayList and the Course arrayList
	public void deleteCourse(String courseID, int num) {
		
		//holds values for the end
		Courses courseToRemove = null;
		boolean tf = false;
		
		//add all  the students courses to an array
		for(Student s : super.getStudent()) {
			Courses[] studsC = new Courses[s.getStudsCourses().size()];
			int i = 0;
			for(Courses c : s.getStudsCourses()) {
				studsC[i] = c;
				i++;	
			}
			ArrayList<Courses> sc = new ArrayList<Courses>();
			s.setStudsCourses(sc);
			
			//iterate through the students courses, and if the course is the one we want to delete, don't add it back to the new ArrayList and save the value to delete later
			//if the course is not the one we want to delete, add it to the ArrayList
			for(Courses course : studsC) {
				if(!course.getCourseID().equals(courseID) || course.getCourseNum() != num) {
					s.getStudsCourses().add(course);
				}
				if(course.getCourseID().equals(courseID) && course.getCourseNum() == num) {
					courseToRemove = course;
					tf = true;
				}
			}
		}
		if(tf) {
			System.out.println("Deleting " + courseToRemove.getCourseName());
			super.getCourse().remove(courseToRemove);
			return;
		}
		
		// if this code executes it means that there are no students in the course
		for(Courses c : super.getCourse()) {
			if(c.getCourseID().equals(courseID) && c.getCourseNum() == num) {
				System.out.println("Deleting " + c.getCourseName());
				super.getCourse().remove(c);
				return;
			}
		}
		
		
	}
	
	//calls the User's viewFullCourses method
	public Object[][] viewFullCourses() {
		System.out.println("Viewing all courses that are full: ");
		boolean fc = false;
		for(int i = 0; i < this.getCourse().size(); i++) {
			if(this.getCourse().get(i).getNumRegStudents() >= this.getCourse().get(i).getMaxStudents()) {
				fc = true;				
			}				
		}
		if(!fc) {
			Object[][] no = {null,null,null,null,null};
			return no;
			
		}
		
	
		return super.viewFullCourses();
	}
	
	//writes the full courses to a file in the same format as when we view a course
	public void writeFullCourses() throws IOException {
		
		
		//location of the txt file that the full courses are written to
		// * need to change when grading
		//change to the location of the storage package + "/Full Courses.txt"
		BufferedWriter br = new BufferedWriter(new FileWriter(System.getProperty("user.dir") + "/src/schwartz/STORAGE/Full Courses.txt"));
		
		boolean tf = false;
		boolean fc = false;
		for(int i = 0; i < super.getCourse().size(); i++) {
			if(this.getCourse().get(i).getNumRegStudents() >= this.getCourse().get(i).getMaxStudents()) {
				fc = true;
				br.write(super.getCourse().get(i).getCourseName() + " | " + super.getCourse().get(i).getCourseID() + " | " 
						+ super.getCourse().get(i).getMaxStudents() + " | " + super.getCourse().get(i).getNumRegStudents() + " | ");
				if(super.getCourse().get(i).getStudInCourse().size() == 0) {
					br.write("none");
				}
				else {
					//data validation for writing purposes
					//formats the students names in the students in course ArrayList
					for(int j = 0; j < super.getCourse().get(i).getStudInCourse().size(); j++) {
						if(super.getCourse().get(i).getStudInCourse().size() == 0) {
							br.write("none");
						}
						else if(super.getCourse().get(i).getStudInCourse().size() == j+1) {
							br.write(super.getCourse().get(i).getStudInCourse().get(j).getLastName() + "," + super.getCourse().get(i).getStudInCourse().get(j).getLastName());
						}
						else {
							br.write(super.getCourse().get(i).getStudInCourse().get(j).getLastName() + "," + super.getCourse().get(i).getStudInCourse().get(j).getFirstName() + "; ");				
						}	
					}
				}
				br.write(" | " + super.getCourse().get(i).getInstructor() + " | " 
						+ super.getCourse().get(i).getCourseNum() + " | " + super.getCourse().get(i).getCourseLoc() + "\n");
					tf = true;
			}
		}
		if(!fc) {
			br.write("There are no full courses");
		}
		if(tf) {
			System.out.println("Full courses written!\n");
		}
		br.close();
	}
	
	//prints a list of the students in a given course
	public String[] studentsInCourse(String courseID) {
		ArrayList<Student> sin = new ArrayList<Student>();

		for(int i = 0; i < this.getCourse().size(); i++) {
			
			if((this.getCourse().get(i).getCourseName() + " " + this.getCourse().get(i).getCourseID() + " " + this.getCourse().get(i).getCourseNum()).equals(courseID)) {
				if(this.getCourse().get(i).getNumRegStudents() == 0) {
					String[] none = {null};
					return none;
				}
				for(Student s : super.getCourse().get(i).getStudInCourse()) {
					sin.add(s);	
				}
			}			
		}
		String[] studs = new String[sin.size()];
		int index = 1;
		for(Student s : sin) {
			studs[index-1] = index + ". " + s.getLastName() + ", " + s.getFirstName();
			index++;
		}
		return studs;
		
		
		
	}
	
	//views a list of the courses a given student is registered in
	public Object[][] studsCourses(String fname, String lname) {
		String name = fname + " " + lname;
		Student cStud = null;
		for(int i = 0; i < super.getStudent().size(); i++) {
			if(name.equals(super.getStudent().get(i).getFirstName() + " " + super.getStudent().get(i).getLastName())){
				cStud = super.getStudent().get(i);
			}
		}
		
		Object[][] course = new Object[cStud.getStudsCourses().size()][5];
		int i = 0;
		for(Courses c : cStud.getStudsCourses()) {
			course[i][0] = c.getCourseName();
			course[i][1] = c.getCourseID();
			course[i][2] = c.getNumRegStudents();
			course[i][3] = c.getInstructor();
			course[i][4] = c.getCourseNum();
			i++;
		}
		
		return course;
	}
		
	//sorts the ArrayList of courses based on the number of students in a course
	public void sort() {
		ArrayList<Courses> al = super.getCourse();
		Collections.sort(al);
		for(Courses c : al) {
			super.printCourse(c);
		}
		System.out.print("\n");
	}
	
	//calls the superclass exit method and serializes the program
	public void exit() {
		super.exit();
	}

	@Override
	public int compareTo(Courses o) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}
