package schwartz.PEOPLE;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.swing.JTable;

import schwartz.COURSES.*;
import schwartz.MAIN.Body;
import schwartz.MAIN.Schwartz;

public abstract class User implements Serializable{
	
	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private static ArrayList<Courses> course = new ArrayList<Courses>();
	private static ArrayList<Student> student = new ArrayList<Student>();
	
	
	public User() {
		
	}
	
	public User(String username, String password, String firstName, String lastName) {
		super();
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	@SuppressWarnings("unchecked")
	//deSerializes the course and student ArrayLists if they are available
	//if not, reads the CSV and imports the courses
	public void addClass() throws IOException, ClassNotFoundException {
		try {
			//creates new ArrayList to add the deserialized courses and students to
		    ArrayList<Student> deStudent = new ArrayList<Student>();
		    ArrayList<Courses> deCourse = new ArrayList<Courses>();
		    
		    //location of the serialized student file
		    // * need to change when grading
		    //change to the location of the storage package + "/Student.ser"
		    FileInputStream fiss = new FileInputStream(System.getProperty("user.dir") + "/src/schwartz/STORAGE/Student.ser");
		    //location of the serialized courses file
		    // * need to change when grading
		    //change to the location of the storage package + "/Course.ser"
		    FileInputStream fisc = new FileInputStream(System.getProperty("user.dir") + "/src/schwartz/STORAGE/Course.ser");
		   
		    ObjectInputStream oiss = new ObjectInputStream(fiss);
		    ObjectInputStream oisc = new ObjectInputStream(fisc);
		    deStudent = (ArrayList<Student>)oiss.readObject();
		    deCourse = (ArrayList<Courses>)oisc.readObject();
		    this.setStudent(deStudent);
		    this.setCourse(deCourse);
		   
		    //validation to make sure the studsCourse is accurate
		    //the studsCourse contains the 
		    if(this.getStudent() == null) {
		    	ArrayList<Student> studs = new ArrayList<Student>();
		    	this.setStudent(studs);
		    }
		    
		    //adding the students back
		    for(int g = 0; g < this.getStudent().size(); g++) {
		    	Student s = this.getStudent().get(g);
		    	ArrayList<Courses> sc = new ArrayList<Courses>();
		    	s.setStudsCourses(sc);
				for(int i = 0; i < this.getCourse().size(); i++) {
					Courses c = this.getCourse().get(i);
					for(int k = 0; k < c.getStudInCourse().size(); k++) {
						Student s2 = c.getStudInCourse().get(k);
						if((s.getUsername() + " " + s.getPassword()).equals(s2.getUsername() + " " + s2.getPassword())) {
							s.getStudsCourses().add(c);
						}
					}
				}
		    }
			
		    //close all the streams
		    oiss.close();
		    fiss.close();
		    oisc.close();
		    fisc.close();
		    System.out.println("Deserialized\n");
			}
		catch(ClassNotFoundException cnfe) {
		       cnfe.printStackTrace();
		       return;
		     }
		catch(IOException x){
			//if there is no file, reads the csv and uses that information to create new courses
			//location of the CSV file
		    // * need to change when grading 
			//change to the location of the data package + "/MyUniversityCoursesFile.csv"
			BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/schwartz/DATA/MyUniversityCoursesFile.csv"));
			String line = "";
			int count = 0;
			while((line = br.readLine()) != null) {
				String[] array = line.split(",");
				if(count > 0) {
					Courses c = new Courses(array[0],array[1],Integer.parseInt(array[2]),Integer.parseInt(array[3]),new ArrayList<Student>(),array[5],Integer.parseInt(array[6]),array[7]);
					this.getCourse().add(c);
				}
				count++;
			}
			br.close();
		    return;
		}
	}
	
	//serializes the course and student ArrayLists and quits the program
	public void exit() {
		try {
			
			//location of the serialized students file
			// * need to change when grading
			//change to the location of the storage package + "/Student.ser"
			FileOutputStream fiss = new FileOutputStream(System.getProperty("user.dir") + "/src/schwartz/STORAGE/Student.ser");
			
			//location of the serialized courses file
			// * need to change when grading
			//change to the location of the storage package + "/Course.ser"
			FileOutputStream fisc = new FileOutputStream(System.getProperty("user.dir") + "/src/schwartz/STORAGE/Course.ser");
			ObjectOutputStream ooss = new ObjectOutputStream(fiss);
			ObjectOutputStream oosc = new ObjectOutputStream(fisc);
			
			ooss.writeObject(User.student);
			oosc.writeObject(User.course);
			
			//close all the streams
			ooss.close();
			fiss.close();
			oosc.close();
			fisc.close();
			System.out.println("Serialization complete");
			System.out.println("Exiting and saving the course registration system");
			Schwartz.input.close();
			System.exit(0);
		} 
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	//prints out all the courses in the course list
	public Object[][] viewAllCourses() {
		/*
		 * Create separate ViewAllCourses class
		 */
		Object[][] course = new Object[this.getCourse().size()][5];
		int i = 0;
		//prints out all the courses
		for(Courses c : this.getCourse()) {
			course[i][0] = c.getCourseName();
			course[i][1] = c.getCourseID();
			course[i][2] = c.getNumRegStudents();
			course[i][3] = c.getInstructor();
			course[i][4] = c.getCourseNum();
			/*
			if(c.getStudInCourse().size() == 0) {
				course[i][3] = "none";
			}
			else {
				String s = "";
				//data validation for printing purposes
				//formats the students names in the students in course ArrayList
				for(int j = 0; j < c.getStudInCourse().size(); j++) {
					if(c.getStudInCourse().size() == j+1) {
						s += c.getStudInCourse().get(j).getLastName() + "," + c.getStudInCourse().get(j).getFirstName();
						System.out.print(c.getStudInCourse().get(j).getLastName() + "," + c.getStudInCourse().get(j).getFirstName());
					}
					else {
						System.out.print(c.getStudInCourse().get(j).getLastName() + "," + c.getStudInCourse().get(j).getFirstName() + "; ");				
					}
						
				}
			}
			System.out.print(" | " + c.getInstructor() + " | " 
					+ c.getCourseNum() + " | " + c.getCourseLoc() + "\n");	
			*/
			i++;
		}
		//System.out.print("\n");
		return course;
		
	}
	
	
	//prints the information for a given course
	public void printCourse(Courses c) {
		System.out.print(c.getCourseName() + " | " + c.getCourseID() + " | " 
				+ c.getMaxStudents() + " | " + c.getNumRegStudents() + " | ");
		if(c.getStudInCourse().size() == 0) {
			System.out.print("none | " + c.getInstructor() + " | " 
					+ c.getCourseNum() + " | " + c.getCourseLoc() + "\n");
		}
		else {
			//data validation for printing purposes
			//formats the students names in the students in course ArrayList
			for(int j = 0; j < c.getStudInCourse().size(); j++) {
				if(c.getStudInCourse().size() == 0) {
					System.out.print("none");
				}
				else if(c.getStudInCourse().size() == j+1) {
					System.out.print(c.getStudInCourse().get(j).getLastName() + "," + c.getStudInCourse().get(j).getFirstName());
				}
				else {
					System.out.print(c.getStudInCourse().get(j).getLastName() + "," + c.getStudInCourse().get(j).getFirstName() + "; ");				
				}
			}
			
			System.out.print(" | " + c.getInstructor() + " | " 
					+ c.getCourseNum() + " | " + c.getCourseLoc() + "\n");
		}
	}
	
	//prints all courses that are full
	public Object[][] viewFullCourses() {
		System.out.println("Viewing all courses that are full: ");
		ArrayList<Courses> nalc = new ArrayList<Courses>();
		
		for(Courses c : this.getCourse()) {
			if(c.getNumRegStudents() >= c.getMaxStudents()) {
				nalc.add(c);
			}
		}
		Object[][] course = new Object[nalc.size()][5];
		int i = 0;
		//prints out all the courses
		for(Courses c : nalc) {
			course[i][0] = c.getCourseName();
			course[i][1] = c.getCourseID();
			course[i][2] = c.getNumRegStudents();
			course[i][3] = c.getInstructor();
			course[i][4] = c.getCourseNum();
			i++;
		}
		
		return course;
	}
	

	//getters and setters
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public ArrayList<Courses> getCourse() {
		return course;
	}

	public void setCourse(ArrayList<Courses> course) {
		User.course = course;
	}

	public ArrayList<Student> getStudent() {
		return student;
	}

	public void setStudent(ArrayList<Student> student) {
		User.student = student;
	}
	
	
	
	 
	
	

}
