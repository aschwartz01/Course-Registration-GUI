package schwartz.MAIN;

import java.io.*;
import java.util.*;


import schwartz.COURSES.*;
import schwartz.PEOPLE.*;

public class Schwartz implements Serializable{
	
	public static final Scanner input = new Scanner(System.in).useDelimiter("\n");

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Admin us = new Admin("Admina","Adminator");
		us.addClass();
		
		/*
		 * /GUI/myGUI.java is the main method that should be used for the GUI
		 */
		/*
		System.out.println("Admin or Student Login: ");
		String lType = input.next();
		if(lType.equals("Admin")) {
			String uname = Body.scannerUname();
			String pword = Body.scannerPword();
			if (uname.equals(us.getUsername())) {
				if(pword.equals(us.getPassword())) {
					System.out.println("Welcome " + us.getFirstName() + " " + us.getLastName());
				}
				else {
					System.out.println("Incorrect Login Information. Goodbye");
					input.close();
					System.exit(0);
				}
				
			}
			else {
				System.out.println("We don't have that Admin registered");
				input.close();
				System.exit(0);
			}
			//Admin methods here
			//admin creates student
			
			
			for (int l = 1; l < 30; l++) {
				us.createNew("UN-" + l, "PW-" + l, "FN" + l, "LN" + l);
			}
			// UN45, PW45, FN45, LN45
			Random random = new Random();
			
			
			for(int q = 0; q < 5; q++) {
				for(int j = 0; j < us.getStudent().size(); j++) {
					int a = random.nextInt(29-0) + 0;
					us.registerOnCourse(us.getCourse().get(a).getCourseName(), us.getCourse().get(a).getCourseID(), us.getStudent().get(j).getFirstName(), us.getStudent().get(j).getLastName());
				}
			}
			
			while(true) {
				int method = Body.scannerAMethod();
				switch (method) {
				case 1://View all courses
					us.viewAllCourses();
					break;
				case 2://View all courses that are full
					us.viewFullCourses();
					break;
				case 3://Write all courses that are full to a file
					us.writeFullCourses();
					break;
				case 4://View the students of a specific course
					String cID = Body.courseSec();
					us.studentsInCourse(cID);
					break;
				case 5://View the courses that a specific student is registered on
					String fNAME = Body.scannerSFName();
					String lNAME = Body.scannerSLName();
					us.studsCourses(fNAME, lNAME);
					break;
				case 6://Sort from highest to lowest
					us.sort();
					break;
				case 7://add new course
					String cname = Body.courseName();
					String cid = Body.courseSec();
					int max = Body.scannerMaxStuds();
					String name = Body.scannerInstructor();
					int cnum = Body.courseNum();
					String cloc = Body.courseLoc();
					us.createNew(cname, cid, max, name, cnum, cloc);
					break;
				case 8://Delete course
					String csec = Body.courseSec();
					us.deleteCourse(csec);
					break;
				case 9://Edit a course
					String idc = Body.courseSec();
					us.editCourse(idc);
					break;
				case 10://Display information for a given course
					String IDC = Body.courseSec();
					us.displayCourseInfo(IDC);
					break;
				case 11://Register a student
					String user = Body.scannerUname();
					String pass = Body.scannerPword();
					String first = Body.scannerFname();
					String last = Body.scannerLname();
					us.createNew(user, pass, first, last);
					break;
				case 12://Exit
					us.exit();
				}				
			}
		}
		else if(lType.equals("Student")) {
			Student stud = null;
			int s = 0;
			String uname = Body.scannerUname();
			if(us.getStudent().size() == 0) {
				System.out.println("There are no students currently registered. Please have the administrator register an account and then you will be able to log in.");
				System.exit(0);
			}
			for(Student i : us.getStudent()) {
				if (uname.equals(i.getUsername())) {
					String pword = Body.scannerPword();
					if(pword.equals(i.getPassword())) {
						System.out.println("Welcome " + i.getFirstName() + " " + i.getLastName());
						stud = i;
						s++;
						stud.setCourse(us.getCourse());
						stud.viewAllCourses();
						break;
					}
					else {
						System.out.println("Incorrect Login Information. Goodbye");
						input.close();
						System.exit(0);
					}
				}
				
			}
			if(s == 0) {
				System.out.println("There are no students registered with that username. Please have the administrator register an account and then you will be able to log in.");
				System.exit(0);
			}
			while(true) {
				int method = Body.scannerSMethod();
				switch (method) {
				case 1:
					stud.viewAllCourses();
					break;
				case 2:
					stud.viewFullCourses();
					break;
				case 3:
					String rName = Body.courseName();
					String rSec = Body.courseSec();
					String rFname = Body.scannerFname();
					String rLname = Body.scannerLname();
					stud.registerOnCourse(rName, rSec, rFname, rLname);
					break;
				case 4:
					String wName = Body.courseName();
					String wSec = Body.courseSec();
					String wFname = Body.scannerFname();
					String wLname = Body.scannerLname();
					stud.withdrawFromCourse(wName, wSec, wFname, wLname);
					break;
				case 5:
					stud.viewMyCourses();
					break;
				case 6:
					stud.exit();
					
			}
				
				
			
		}
		*/
		/*
		Admin ad = new Admin("UName","PWord","Admin","Adminator");
		us.viewAllCourses();
		ad.viewAllCourses();
		Admin as = new Admin("default","default","default","default");
		Student s1 = new Student("Username","Password","Student", "One");//ISSUE: THE STUDENT AND ADMIN CAN'T ACCESS THE SAME ARRAY LISTS
		us.getStudent().add(s1);
		System.out.println();
		as.deleteCourse("CSCI-UA.0465");
		as.viewAllCourses();
		System.out.println();
		System.out.println("as.getCourse().size(): " + as.getCourse().size());
		System.out.println("s1.getCourse().size(): " + s1.getCourse().size());
		s1.registerOnCourse("Compiler Construction", "CSCI-GA.2130", "Student", "One");
		as.viewAllCourses();
		System.out.println();
		System.out.println();
		as.displayCourseInfo("CSCI-GA.2130");
		System.out.println();
		as.exit();
		*/
	}

}

