package schwartz.MAIN;

import java.io.Serializable;
import java.util.Scanner;

import schwartz.PEOPLE.*;

public class Body implements Serializable{
	
	
	
	public static String scannerUname() {
		System.out.println("Enter a username: ");
		String uname = Schwartz.input.next();
		return uname;
	}
	
	public static String scannerPword() {
		System.out.println("Enter a password: ");
		String pword = Schwartz.input.next();
		return pword;
	}
	
	public static String scannerFname() {
		System.out.println("Enter your first name: ");
		String fname = Schwartz.input.next();
		return fname;
	}
	
	public static String scannerLname() {
		System.out.println("Enter your last name: ");
		String lname = Schwartz.input.next();
		return lname;
	}
	
	public static int scannerSMethod() {
		System.out.println("Which method would you like to do?\n\t(1) View all courses\n\t(2) View all courses that are not full\n\t(3) Register on a course\n\t(4) Withdraw from a course\n\t(5) View all courses you are registered on\n\t(6) Exit");
		String method = Schwartz.input.next();
		return Integer.parseInt(method);
	}
	
	public static int scannerAMethod() {
		System.out.println("Which method/report would you like to try?\n*****Reports*****\n\t(1) View all courses\n\t(2) View all courses that are full\n\t(3) Write to a file the list of courses that are full\n\t(4) View the names of the students being registered in a specific course\n\t(5) View the list of courses that a given student is being registered on\n\t"
				+ "(6) Sort courses based on number of students currently registered\n*****Methods*****\n\t(7) Create a new course \n\t(8) Delete a course\n\t(9) Edit a course \n\t(10) Display information for a given course\n\t(11) Register a student\n\t(12) Exit");
		String method = Schwartz.input.next();
		return Integer.parseInt(method);
	}
	
	public static String scannerReport() {
		System.out.println("Which report would you like to view? ");
		String report = Schwartz.input.next();
		return report;
	}
	
	public static String courseName() {
		System.out.println("Enter the name of the course: ");
		String name = Schwartz.input.next();
		return name;
	}
	
	public static String courseSec() {
		System.out.println("Enter the section of the course: ");
		String sec = Schwartz.input.next();
		return sec;
	}
	
	public static String scannerSFName() {
		System.out.println("Enter a student's first name: ");
		String fname = Schwartz.input.next();
		return fname;
	}
	
	public static String scannerSLName() {
		System.out.println("Enter the same student's last name: ");
		String lname = Schwartz.input.next();
		return lname;
	}
	
	public static int scannerMaxStuds() {
		System.out.println("Enter the maximum number of students for this course: ");
		String max = Schwartz.input.next();
		return Integer.parseInt(max);
	}
	
	public static String scannerInstructor() {
		System.out.print("Enter the instructor's first name ");
		String fname = Schwartz.input.nextLine();
		System.out.print("and last name:");
		String lname = Schwartz.input.nextLine();
		String name = fname + " " + lname;
		return name;
	}
	
	public static int courseNum() {
		System.out.println("Enter the course number: ");
		String cnum = Schwartz.input.next();
		return Integer.parseInt(cnum);
	}
	
	public static String courseLoc() {
		System.out.println("Enter the course location: ");
		String cloc = Schwartz.input.next();
		return cloc;
	}
	
	

}
