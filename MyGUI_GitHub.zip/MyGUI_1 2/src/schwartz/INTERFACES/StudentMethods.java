package schwartz.INTERFACES;

public interface StudentMethods {

}
