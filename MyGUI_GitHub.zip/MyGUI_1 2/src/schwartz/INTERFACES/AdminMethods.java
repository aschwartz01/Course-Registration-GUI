package schwartz.INTERFACES;

import java.util.ArrayList;

import schwartz.COURSES.Courses;
import schwartz.PEOPLE.Student;

public interface AdminMethods {
	
	public void createNew(String className, String cID, int maxStuds, String instructor, int cNum, String cLoc);
	
	public void createNew(String username, String password, String firstName, String lastName);
	
	public String editCourse(String courseID, int cNum, String answer, String input, String edit);
	
	public Object[] displayCourseInfo(String courseID, int cNum);
	
	public void deleteCourse(String courseID, int cNum);

	

}
