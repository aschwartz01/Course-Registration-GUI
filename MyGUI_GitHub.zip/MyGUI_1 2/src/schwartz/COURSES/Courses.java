package schwartz.COURSES;

import java.io.Serializable;
import java.util.ArrayList;

import schwartz.PEOPLE.Student;

public class Courses implements Serializable, Comparable{
	
	private String courseName;
	private String courseID;
	private int maxStudents;
	private int numRegStudents;
	private ArrayList<Student> studInCourse;
	private String instructor;
	private int courseNum;
	private String courseLoc;
	
	
	
	public Courses(String courseName, String courseID, int maxStudents, int numRegStudents,
			ArrayList<Student> studInCourse, String instructor, int courseNum, String courseLoc) {
		super();
		this.courseName = courseName;
		this.courseID = courseID;
		this.maxStudents = maxStudents;
		this.studInCourse = new ArrayList<Student>();
		this.numRegStudents = this.studInCourse.size();
		this.instructor = instructor;
		this.courseNum = courseNum;
		this.courseLoc = courseLoc;
	}
	
	@Override //used by the admin to sort the courses
	public int compareTo(Object o) {
		int compareage = ((Courses) o).getNumRegStudents();
		return compareage-this.getNumRegStudents();
	}
	
	//getters and setters
	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	public int getMaxStudents() {
		return maxStudents;
	}

	public void setMaxStudents(int maxStudents) {
		this.maxStudents = maxStudents;
	}

	public int getNumRegStudents() {
		//automatically updates to be the number of students in the given course
		this.numRegStudents = this.studInCourse.size();
		return numRegStudents;
	}

	public void setNumRegStudents(int numRegStudents) {
		this.numRegStudents = numRegStudents;
	}

	public ArrayList<Student> getStudInCourse() {
		return studInCourse;
	}

	public void setStudInCourse(ArrayList<Student> studInCourse) {
		this.studInCourse = studInCourse;
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	public int getCourseNum() {
		return courseNum;
	}

	public void setCourseNum(int courseNum) {
		this.courseNum = courseNum;
	}

	public String getCourseLoc() {
		return courseLoc;
	}

	public void setCourseLoc(String courseLoc) {
		this.courseLoc = courseLoc;
	}

}
