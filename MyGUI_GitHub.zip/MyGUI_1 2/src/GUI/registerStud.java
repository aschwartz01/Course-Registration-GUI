package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class registerStud {
	
	JFrame frame1;
	JLabel unameLabel = new JLabel("Username:");
	JLabel pwordLabel = new JLabel("Password:");
	JTextField uTEXT;
	JTextField pTEXT;
	JButton enterU;
	JButton enterP;
	InputHandler uHandler = new InputHandler();
	InputHandler pHandler = new InputHandler();
	JLabel message = new JLabel();
	JLabel message2 = new JLabel();
	String uname ;
	String pword;
	JLabel req;
	JLabel req2;
	String cName;
	String cID;
	int cNum;
	JButton mainMenu;
	String rtype;
	
	public registerStud(String cname, String cid, int cn, String registerType) {
		cName = cname;
		cID = cid;
		cNum = cn;
		rtype = registerType;
		
		//super.frame.dispose();
		frame1 = new JFrame();
		frame1.setBounds(100, 100, 600, 450);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.setLayout(null);
		frame1.setVisible(true);
		
		
		req = new JLabel("Enter the student you would like to register");
		req.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req.setHorizontalAlignment(SwingConstants.CENTER);
		req.setBounds(42, 10, 566, 30);
		frame1.add(req);
		req2 = new JLabel("on " + cname);
		req2.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req2.setHorizontalAlignment(SwingConstants.CENTER);
		req2.setBounds(42, 30, 566, 30);
		frame1.add(req2);
		
		unameLabel = new JLabel("First Name:");
		unameLabel.setBounds(6, 75, 183, 81);
		
		
		pwordLabel = new JLabel("Last Name:");
		pwordLabel.setBounds(6, 160, 183, 81);
		
		frame1.add(unameLabel);
		frame1.add(pwordLabel);
		
		uTEXT = new JTextField();
		uTEXT.setBounds(180, 75, 183, 81);
		JButton enterU = new JButton("Enter");
		enterU.setForeground(new Color(148, 0, 211));
		enterU.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterU.setBackground(new Color(0, 0, 0));
		enterU.setBounds(370, 75, 183, 81);
		enterU.addActionListener(uHandler);
		//frame1.add(enterU);
		
		
		pTEXT = new JTextField();
		pTEXT.setBounds(180, 160, 183, 81);
		JButton enterP = new JButton("Enter");
		enterP.setForeground(new Color(148, 0, 211));
		enterP.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterP.setBackground(new Color(0, 0, 0));
		enterP.setBounds(370, 160, 183, 81);
		enterP.addActionListener(pHandler);
		frame1.add(enterP);
		
		
		frame1.add(uTEXT);
		frame1.add(pTEXT);
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 225, 412, 81);
		frame1.add(message);
		
		
		message2.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		message2.setHorizontalAlignment(SwingConstants.CENTER);
		message2.setBounds(55, 250, 412, 81);
		frame1.add(message2);
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(180, 315, 183, 81);
		frame1.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					//frame1.dispose();
					
					frame1.dispose();
					adminMethods s = new adminMethods();
					
				}	
			}
		});
		
		
	}
	
	public void addToFrame(int n, String fname, String lname) {
		String studName = fname + " " + lname;
		if(n == 1) {
			message.setText("Trying to register" + studName);
			message.setText("on " + cName);
			/*
			 * Call the new Class making the new window with all the options of what the admin can do
			 */
			if(rtype.equals("register")) {
				boolean r = myGUI.us.registerOnCourse(cName, cID, fname, lname, cNum);
				
				if(r) {
					message.setText(studName + " is now registered");
					message2.setText("on " + cName);
				}
				else {
					message.setText("Could not register " + studName);
					message2.setText("on " + cName);
				}
			}
			else if(rtype.equals("edit")) {
				String r = myGUI.us.editCourse(cID, cNum, "registered", fname + "-" + lname,"add");
				if(r.length() > 40) {
					String[] mess = r.split(" ");
					String s1 = "";
					String s2 = "";
					int count = 0;
					for(String i : mess) {
						if(count < (mess.length/2)+1) {
							s1 += i + " ";
						}
						else {
							s2 += i + " ";
						}
						count++;
					}
					message.setText(s1);
					message2.setText(s2);
				}
				else {
					message.setText(r);
				}
				
			}
			
		}
		else if(n == 2) {
			message.setText("Incorrect Password");
		}
		else if(n == 3) {
			message.setText("Student not listed");
		}
	}
	
	
	public class InputHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String utext = uTEXT.getText();
			String ptext = pTEXT.getText();
			boolean tf = false;
			for(int i = 0; i < myGUI.us.getStudent().size(); i++) {
				System.out.println(myGUI.us.getStudent().get(i).getFirstName());
				if (utext.equals(myGUI.us.getStudent().get(i).getFirstName())) {
					
					tf = true;
					if(ptext.equals(myGUI.us.getStudent().get(i).getLastName())) {
						addToFrame(1, utext, ptext);
						return;
						
					}
					else {
						addToFrame(2,utext, ptext);
						return;
					}
				}
			}
			if(!tf) {
				addToFrame(3,utext, ptext);
			}
		}
	}

}
