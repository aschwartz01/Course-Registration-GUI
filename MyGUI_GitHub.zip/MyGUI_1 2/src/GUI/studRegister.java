package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import schwartz.PEOPLE.Student;

public class studRegister {
	
	private JFrame frame;
	private JLabel unameLabel = new JLabel("Username:");
	private JLabel pwordLabel = new JLabel("Password:");
	private JTextField uTEXT;
	private JTextField pTEXT;
	private JButton enterU;
	private JButton enterP;
	InputHandler uHandler = new InputHandler();
	InputHandler pHandler = new InputHandler();
	private JLabel message = new JLabel();
	String uname ;
	String pword;
	private JLabel req;
	private JLabel req2;
	String cName;
	String cID;
	int cNum;
	private JButton mainMenu;
	Student student;
	
	public studRegister(String cname, String cid, int cn, Student stud) {
		student = stud;
		//super.frame.dispose();
		cName = cname;
		cID = cid;
		cNum = cn;
		
		
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);
		
		
		req = new JLabel("Enter your username and password to confirm");
		req.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req.setHorizontalAlignment(SwingConstants.CENTER);
		req.setBounds(42, 10, 566, 30);
		frame.add(req);
		req2 = new JLabel("registration on " + cname);
		req2.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req2.setHorizontalAlignment(SwingConstants.CENTER);
		req2.setBounds(42, 30, 566, 30);
		frame.add(req2);
		
		unameLabel = new JLabel("Username:");
		unameLabel.setBounds(6, 75, 183, 81);
		
		
		pwordLabel = new JLabel("Password:");
		pwordLabel.setBounds(6, 160, 183, 81);
		
		frame.add(unameLabel);
		frame.add(pwordLabel);
		
		uTEXT = new JTextField();
		uTEXT.setBounds(180, 75, 183, 81);
		
		
		pTEXT = new JTextField();
		pTEXT.setBounds(180, 160, 183, 81);
		JButton enterP = new JButton("Enter");
		enterP.setForeground(new Color(148, 0, 211));
		enterP.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterP.setBackground(new Color(0, 0, 0));
		enterP.setBounds(370, 160, 183, 81);
		enterP.addActionListener(pHandler);
		frame.add(enterP);
		
		
		frame.add(uTEXT);
		frame.add(pTEXT);
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 225, 412, 81);
		
		frame.add(message);
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(180, 285, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					
					frame.dispose();
					studentMethods s = new studentMethods(stud);
					
				}	
			}
		});
		
	}
	
	public void addOnFrame(int n) {
		if(n == 1) {
			message.setText("Trying to register on " + cName);
			/*
			 * Call the new Class making the new window with all the options of what the admin can do
			 */
			
			boolean r = student.registerOnCourse(cName, cID, cNum, student.getFirstName(), student.getLastName());
			
			if(r) {
				message.setText("Registered on " + cName);
			}
			else {
				message.setText("Could not register on " + cName);
			}
		}
		else if(n == 2) {
			message.setText("Incorrect Login Information");
		}
		else if(n == 3) {
			message.setText("Incorrect Student");
		}
	}
	
	
	public class InputHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String utext = uTEXT.getText();
			String ptext = pTEXT.getText();
			System.out.println(utext + " " + student.getUsername());
			System.out.println(ptext + " " + student.getPassword());
			
			if (utext.equals(student.getUsername())) {
				if(ptext.equals(student.getPassword())) {
					addOnFrame(1);
				}
				else {
					addOnFrame(2);
					
				}
			}
			else {
				addOnFrame(3);
			}
		}
	}
}
