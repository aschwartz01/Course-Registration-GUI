package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class createNewCourse {
	
	JFrame frame;
	JLabel unameLabel = new JLabel("Username:");
	JLabel pwordLabel = new JLabel("Password:");
	JTextField uTEXT;
	JTextField pTEXT;
	JLabel maxStuds ;
	JLabel instructor;
	JTextField maxTEXT;
	JTextField instTEXT;
	JLabel num ;
	JLabel location;
	JTextField numTEXT;
	JTextField locTEXT;
	JButton enterU;
	JButton enterP;
	InputHandler uHandler = new InputHandler();
	InputHandler pHandler = new InputHandler();
	JLabel message = new JLabel();
	String uname ;
	String pword;
	JLabel req;
	JLabel req2;
	JButton mainMenu;
	String cName;
	
	public createNewCourse() {

		frame = new JFrame();
		frame.setBounds(100, 100, 600, 790);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);
		
		
		req = new JLabel("Enter the information for the");
		req.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req.setHorizontalAlignment(SwingConstants.CENTER);
		req.setBounds(42, 10, 566, 30);
		frame.add(req);
		req2 = new JLabel("course you would like to create");
		req2.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req2.setHorizontalAlignment(SwingConstants.CENTER);
		req2.setBounds(42, 30, 566, 30);
		frame.add(req2);
		
		frame.add(unameLabel);
		frame.add(pwordLabel);
		
		unameLabel = new JLabel("Course Name:");
		unameLabel.setBounds(6, 75, 183, 81);
		uTEXT = new JTextField();
		uTEXT.setBounds(180, 75, 183, 81);
		
		
		pwordLabel = new JLabel("Course ID:");
		pwordLabel.setBounds(6, 160, 183, 81);
		pTEXT = new JTextField();
		pTEXT.setBounds(180, 160, 183, 81);
		
		
		maxStuds = new JLabel("Maximum Students:");
		maxStuds.setBounds(6, 245, 183, 81);
		maxTEXT = new JTextField();
		maxTEXT.setBounds(180, 245, 183, 81);
		
		
		instructor = new JLabel("Instructor:");
		instructor.setBounds(6, 330, 183, 81);
		instTEXT = new JTextField();
		instTEXT.setBounds(180, 330, 183, 81);
		
		
		num = new JLabel("Course Number:");
		num.setBounds(6, 415, 183, 81);
		numTEXT = new JTextField();
		numTEXT.setBounds(180, 415, 183, 81);
		
		
		location = new JLabel("Course Location:");
		location.setBounds(6, 500, 183, 81);
		locTEXT = new JTextField();
		locTEXT.setBounds(180, 500, 183, 81);
		
		
		frame.add(unameLabel);
		frame.add(pwordLabel);
		frame.add(maxStuds);
		frame.add(instructor);
		frame.add(num);
		frame.add(location);
		
		frame.add(uTEXT);
		frame.add(pTEXT);
		frame.add(maxTEXT);
		frame.add(instTEXT);
		frame.add(numTEXT);
		frame.add(locTEXT);
		
		JButton enterP = new JButton("Enter");
		enterP.setForeground(new Color(148, 0, 211));
		enterP.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterP.setBackground(new Color(0, 0, 0));
		enterP.setBounds(370, 500, 183, 81);
		enterP.addActionListener(pHandler);
		frame.add(enterP);
		
		
		
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 550, 412, 81);
		
		frame.add(message);
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(180, 625, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					frame.dispose();
					adminMethods s = new adminMethods();
					
				}	
			}
		});
		
		
	}
	
	public void addOnFrame(int n, String cName, String instructor) {
		if(n == 1) {
			message.setText(cName + " with " + instructor + " has been created.");
		}
		else if(n == 2) {
			message.setText("Incorrect Password. Goodbye");
		}
		else if(n == 3) {
			message.setText("Incorrect Student");
		}
	}
	
	
	public class InputHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			frame.add(uTEXT);
			frame.add(pTEXT);
			frame.add(maxTEXT);
			frame.add(instTEXT);
			frame.add(numTEXT);
			frame.add(locTEXT);
			String utext = uTEXT.getText();
			String ptext = pTEXT.getText();
			String maxtext = maxTEXT.getText();
			String insttext = instTEXT.getText();
			String numtext = numTEXT.getText();
			String loctext = locTEXT.getText();
			myGUI.us.createNew(utext, ptext, Integer.parseInt(maxtext), insttext, Integer.parseInt(numtext), loctext);
			
			addOnFrame(1, utext, insttext);
			
			
		}
	}

}
