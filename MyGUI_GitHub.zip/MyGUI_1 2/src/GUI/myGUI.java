package GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Random;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

import schwartz.PEOPLE.Admin;

import javax.swing.JLabel;

public class myGUI implements ActionListener{

	private JFrame frame;
	private JFrame adLoginFrame;
	
	private JButton adminLogin;
	private JButton studLogin;
	
	public static Admin us = new Admin("Adam","Schwartz");

	/**
	 * Launch the application.
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		us = new Admin("Adam","Schwartz");
		System.out.println(us.getFirstName() + "\t" + us.getLastName());
		System.out.println(us.getUsername() + "\t" + us.getPassword());
		
		us.addClass();
		
		/*
		//tester code to auto create students and enroll them randomly in courses		
		for (int l = 1; l < 30; l++) {
			us.createNew("UN-" + l, "PW-" + l, "FN" + l, "LN" + l);
		}
		
		Random random = new Random();
		
		
		for(int q = 0; q < 5; q++) {
			for(int j = 0; j < us.getStudent().size(); j++) {
				int a = random.nextInt(29-0) + 0;
				us.registerOnCourse(us.getCourse().get(a).getCourseName(), us.getCourse().get(a).getCourseID(), us.getStudent().get(j).getFirstName(), us.getStudent().get(j).getLastName(),us.getCourse().get(a).getCourseNum());
			}
		}
		
		*/
		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					myGUI window = new myGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public myGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel loginQuestion = new JLabel("Would you like to login as an Admin or a Student?");
		loginQuestion.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		loginQuestion.setHorizontalAlignment(SwingConstants.CENTER);
		loginQuestion.setBounds(93, 97, 412, 81);
		frame.getContentPane().add(loginQuestion);

		
		JButton adminLogin = new JButton("Admin");
		adminLogin.setForeground(new Color(148, 0, 211));
		adminLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		adminLogin.setBackground(new Color(0, 0, 0));
		adminLogin.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(adminLogin);
		
		adminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == adminLogin) {
					frame.dispose();
					adminLoginWindow alw = new adminLoginWindow() ;
				}	
			}
		});
		
		JButton studLogin = new JButton("Student");
		studLogin.setForeground(new Color(148, 0, 211));
		studLogin.setBackground(new Color(0, 0, 0));
		studLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		studLogin.setBounds(411, 247, 183, 81);
		frame.getContentPane().add(studLogin);
		
		studLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == studLogin) {
					frame.dispose();
					studentLoginWindow slw = new studentLoginWindow() ;
				}	
			}
		});
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
}
