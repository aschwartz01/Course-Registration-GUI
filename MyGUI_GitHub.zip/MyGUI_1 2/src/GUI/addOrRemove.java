package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;



public class addOrRemove implements ActionListener{
	
	JFrame frame;
	JLabel question;
	JButton adminLogin;
	JButton studLogin;
	JButton mainMenu;
	
	public addOrRemove(String cname, String cid, int cnum, String menu) {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		question = new JLabel("Would you like to add or remove a student?");
		question.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		question.setHorizontalAlignment(SwingConstants.CENTER);
		question.setBounds(93, 97, 412, 81);
		frame.getContentPane().add(question);

		
		JButton adminLogin = new JButton("Add");
		adminLogin.setForeground(new Color(148, 0, 211));
		adminLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		adminLogin.setBackground(new Color(0, 0, 0));
		adminLogin.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(adminLogin);
		
		adminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == adminLogin) {
					frame.dispose();
					registerStud rs = new registerStud(cname, cid, cnum, "edit");
				}	
			}
		});
		
		JButton studLogin = new JButton("Delete");
		studLogin.setForeground(new Color(148, 0, 211));
		studLogin.setBackground(new Color(0, 0, 0));
		studLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		studLogin.setBounds(411, 247, 183, 81);
		frame.getContentPane().add(studLogin);
		
		studLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == studLogin) {
					frame.dispose();
					listStuds_Delete sr = new listStuds_Delete("Students in " + cname, myGUI.us.studentsInCourse(cname + " " + cid + " "  + cnum), "Admin", cid, cnum);
				}	
			}
		});
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					if(menu.equals("Admin")) {
						frame.dispose();
						adminMethods a = new adminMethods();
					}
					
				}	
			}
		});
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
