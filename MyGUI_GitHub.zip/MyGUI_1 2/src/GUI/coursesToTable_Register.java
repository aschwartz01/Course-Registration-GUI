package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventObject;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;


public class coursesToTable_Register  implements TableCellRenderer, TableCellEditor{
	
	JFrame frame;
	JTable table1;
	JScrollPane jsp1;
	DefaultTableModel dtm1;
	JTableHeader jth1;
	JPanel jp1;
	JButton mainMenu;
	JButton rb;
	ListSelectionModel select;
	JLabel message = new JLabel();
	
	public coursesToTable_Register(String label, Object[][] data, String menu, String WorR) {
		final Object[][] data1 = data;
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp1 = new JPanel();
		frame.setVisible(true); 
		
		JLabel viewAll = new JLabel(label);
		viewAll.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		viewAll.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll.setBounds(6, 10, 588, 30);
		frame.getContentPane().add(viewAll, BorderLayout.NORTH);
		
		
		Object[] s = {"Course Name","Course ID","Maximum Students","# of Registered Students","Course #"};
		DefaultTableModel model = new DefaultTableModel(data,s);
		JTable table = new JTable(model);
		
		
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		JTableHeader header = table.getTableHeader();
		header.setBackground(new Color(148, 0, 211));
		header.setForeground(Color.white);
		
		
		jsp1 = new JScrollPane(table);
		jp1.add(jsp1);

		message.setFont(new Font("Lucida Grande", Font.BOLD, 24));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 500, 412, 81);
		frame.add(message);
		
		select = table.getSelectionModel();
		select.addListSelectionListener(new ListSelectionListener() {


			@Override
			public void valueChanged(ListSelectionEvent e) {
				int row = select.getMinSelectionIndex();
				if(menu.equals("Admin")) {
					if(WorR.equals("registerStud")) {
						frame.dispose();
						System.out.println("Which course would you like to register a student on?");
						registerStud rs = new registerStud((String)data[row][0],(String)data[row][1],(int)data[row][4], "register");
					}
					else if(WorR.equals("deleteCourse")) {
						System.out.println(data[row][1] + " " + data[row][2]);
						myGUI.us.deleteCourse((String)data[row][1], (int)data[row][2]);
						message.setText(data[row][0] + " has been deleted");
						
					}
					
					else if(WorR.equals("displayCourseInfo")) {
						frame.dispose();
						Object[][] cInfo = myGUI.us.displayCourseInfo((String)data[row][1],(int)data[row][2]);
						displayTable dt = new displayTable("Displaying " + data[row][0] +"'s Information:", cInfo, "Admin");
					}
					
				}
				
			}
		
		});
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					if(menu.equals("Admin")) {
						frame.dispose();
						adminMethods a = new adminMethods();
					}
				}	
			}
		});
		
		jp1.setBounds(6, 50, 588, 600);
		frame.getContentPane().add(jp1, BorderLayout.CENTER);
		frame.setSize(600, 700);
		
		
	}

	@Override
	public Object getCellEditorValue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isCellEditable(EventObject anEvent) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean shouldSelectCell(EventObject anEvent) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean stopCellEditing() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void cancelCellEditing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addCellEditorListener(CellEditorListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeCellEditorListener(CellEditorListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		// TODO Auto-generated method stub
		return null;
	}

}
