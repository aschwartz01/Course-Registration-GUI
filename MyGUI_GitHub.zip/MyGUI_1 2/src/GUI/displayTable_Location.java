package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class displayTable_Location implements ActionListener {

	JFrame frame;
	JTable table1;
	JScrollPane jsp1;
	DefaultTableModel dtm1;
	JTableHeader jth1;
	JPanel jp1;
	JButton mainMenu;

	JLabel maxSelect = new JLabel();
	JTextField maxSelected = new JTextField();
	JButton maxxed;
	
	JLabel message = new JLabel();
	JLabel message2 = new JLabel();
	String cName;
	String cID;
	int cNum;
	
	
	public displayTable_Location(String cname, String cid, int cnum, String menu) {
		
		
		cName = cname;
		cID = cid;
		cNum = cnum;
		
		
		//frame.add(table1);
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp1 = new JPanel();
		frame.setVisible(true); 
		
		JLabel viewAll = new JLabel("Enter the new location for");
		viewAll.setFont(new Font("Lucida Grande", Font.BOLD, 24));
		viewAll.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll.setBounds(6, 10, 588, 30);
		jp1.add(viewAll, BorderLayout.NORTH);
		JLabel viewAll1 = new JLabel(cname);
		viewAll1.setFont(new Font("Lucida Grande", Font.BOLD, 24));
		viewAll1.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll1.setBounds(15, 30, 588, 30);
		jp1.add(viewAll1, BorderLayout.CENTER);
		
		
		
		Object[] s = {"","Information"};
		DefaultTableModel model = new DefaultTableModel(myGUI.us.displayCourseInfo(cid, cnum),s);
		JTable table = new JTable(model);
		table.getColumn("").setCellRenderer(new ColumnColorRenderer(new Color(148, 0, 211), Color.white,true));
		
		
		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.BLACK);
		header.setForeground(Color.white);
		
		jsp1 = new JScrollPane(table);
		jp1.add(jsp1, BorderLayout.CENTER);
		
		
		maxSelect.setText("New location:");
		maxSelect.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		maxSelect.setHorizontalAlignment(SwingConstants.CENTER);
		maxSelect.setBounds(12, 500, 210, 81);
		frame.add(maxSelect);
		
		
		maxSelected.setHorizontalAlignment(SwingConstants.CENTER);
		maxSelected.setBounds(230, 500, 200, 81);
		frame.add(maxSelected);
		
		maxxed = new JButton("Enter");
		maxxed.setForeground(new Color(148, 0, 211));
		maxxed.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		maxxed.setBackground(new Color(0, 0, 0));
		maxxed.setBounds(445, 500, 140, 81);
		maxxed.addActionListener(this);
		frame.add(maxxed);
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(5, 575, 590, 81);
		frame.add(message, BorderLayout.CENTER);
		
		message2.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		message2.setHorizontalAlignment(SwingConstants.CENTER);
		message2.setBounds(5, 600, 590, 81);
		frame.add(message2, BorderLayout.CENTER);
		
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(6, 247, 183, 81);
		frame.add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					System.out.println("menu: " + menu);
					
					if(menu.equals("Admin")) {
						frame.dispose();
						adminMethods a = new adminMethods();
					}
				}
				
			}
		});
		
		
		jp1.setBounds(6, 75, 588, 600);
		frame.add(jp1, BorderLayout.CENTER);
		frame.setSize(600, 750);
		 	
	}
	
	public class ColumnColorRenderer extends DefaultTableCellRenderer{
		
		Color p = new Color(148, 0, 211);
		Color w = Color.white;
		boolean tf;
		
		public ColumnColorRenderer(Color p, Color w, boolean tf) {
			super();
			this.p = p;
			this.w = w;
			this.tf = tf;
		}
		
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
			c.setBackground(p);
			c.setForeground(w);
			return c;
			
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == maxxed) {
			String newmax = maxSelected.getText();
			System.out.println("new location: " + newmax);
			String newMax = myGUI.us.editCourse(cID,cNum, "location", newmax, "");
			System.out.println(newMax);
			if(newMax.length() > 40) {
				String[] mess = newMax.split(" ");
				String s1 = "";
				String s2 = "";
				int count = 0;
				for(String i : mess) {
					if(count < (mess.length/2)+1) {
						s1 += i + " ";
					}
					else {
						s2 += i + " ";
					}
					count++;
				}
				message.setText(s1);
				message2.setText(s2);
			}
			else {
				message.setText(newMax);
			}
			
		}
		
	}
}
