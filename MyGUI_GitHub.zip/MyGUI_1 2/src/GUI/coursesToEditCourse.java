package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;


public class coursesToEditCourse implements ActionListener{
	
	JFrame frame;
	JTable table1;
	JScrollPane jsp1;
	DefaultTableModel dtm1;
	JTableHeader jth1;
	JPanel jp1;
	JButton rb;
	JButton mainMenu;
	JButton maxStuds;
	JButton regInC;
	JButton instructor;
	JButton courseLoc;
	String cName;
	String cID;
	int cNum;
	JLabel message = new JLabel();
	
	
	static Object[][] data1;
	//Edit course
	public coursesToEditCourse(String cname, String cid, int cnum, String menu) {
		cName = cname;
		cID = cid;
		cNum = cnum;

		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp1 = new JPanel();
		frame.setVisible(true); 
		JLabel viewAll = new JLabel("What information would you like to edit for");
		viewAll.setFont(new Font("Lucida Grande", Font.BOLD, 26));
		viewAll.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll.setBounds(6, 10, 588, 30);
		frame.add(viewAll);
		
		JLabel viewAll1 = new JLabel(cname + "?");
		viewAll1.setFont(new Font("Lucida Grande", Font.BOLD, 26));
		viewAll1.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll1.setBounds(6, 40, 588, 30);
		frame.getContentPane().add(viewAll1);
		
		
		maxStuds = new JButton("Maximum Students in the Course");
		maxStuds.setForeground(new Color(148, 0, 211));
		maxStuds.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		maxStuds.setBackground(new Color(0, 0, 0));
		maxStuds.setBounds(6, 155, 582, 50);
		maxStuds.addActionListener(this);
		frame.add(maxStuds, BorderLayout.CENTER);
		
		regInC = new JButton("Students Registered in the Course");
		regInC.setForeground(new Color(148, 0, 211));
		regInC.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		regInC.setBackground(new Color(0, 0, 0));
		regInC.setBounds(6, 205, 582, 50);
		regInC.addActionListener(this);
		frame.add(regInC, BorderLayout.CENTER);
		
		instructor = new JButton("Current Instructor");
		instructor.setForeground(new Color(148, 0, 211));
		instructor.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		instructor.setBackground(new Color(0, 0, 0));
		instructor.setBounds(6, 255, 582, 50);
		instructor.addActionListener(this);
		frame.add(instructor, BorderLayout.CENTER);
		
		courseLoc = new JButton("Course Location");
		courseLoc.setForeground(new Color(148, 0, 211));
		courseLoc.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		courseLoc.setBackground(new Color(0, 0, 0));
		courseLoc.setBounds(6, 305, 582, 50);
		courseLoc.addActionListener(this);
		frame.add(courseLoc, BorderLayout.CENTER);
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(5, 575, 590, 81);
		frame.add(message, BorderLayout.CENTER);
		  
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					//frame.dispose();
					if(menu.equals("Admin")) {
						frame.dispose();
						adminMethods a = new adminMethods();
					}
				}	
			}
		});
		
		jp1.setBounds(6, 50, 588, 600);
		frame.getContentPane().add(jp1, BorderLayout.CENTER);
		frame.setSize(600, 700);
		}
	
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == maxStuds) {
				frame.dispose();
				displayTable_maxStuds dtms = new displayTable_maxStuds(cName, cID, cNum, "Admin");		
			}
			else if(e.getSource() == regInC) {
				System.out.println("regInC");
				frame.dispose();
				addOrRemove rs = new addOrRemove(cName, cID, cNum, "Admin");
			}
			else if(e.getSource() == instructor) {
				System.out.println("change instrucotr");
				frame.dispose();
				displayTable_instructor dtms = new displayTable_instructor(cName, cID, cNum, "Admin");
			}
			else if(e.getSource() == courseLoc) {
				System.out.println("change courseLoc");
				frame.dispose();
				displayTable_Location dtms = new displayTable_Location(cName, cID, cNum, "Admin");
			}	
		}
}
