package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import schwartz.COURSES.Courses;
import schwartz.PEOPLE.Student;

public class studentMethods implements ActionListener {
	
	JFrame frame1;
	JLabel studentsReports;
	JButton viewAll;
	JButton viewFull;
	JButton withdraw;
	JButton register;
	JButton studsCourse;
	JButton sort;
	JLabel studentsMethods;
	JButton newCourse;
	JButton deleteCourse;
	JButton editCourse;
	JButton displayCourseInfo;
	JButton registerStud;
	JButton exit;
	JTable table1;
	JScrollPane jsp1;
	Student stud;
	
	
	public studentMethods(Student i) {
		stud = i;
		frame1 = new JFrame();
		frame1.setBounds(120, 700, 650, 450);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.setLayout(null);
		frame1.setVisible(true);
		
		studentsReports = new JLabel("****Student's Methods****");
		studentsReports.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		studentsReports.setHorizontalAlignment(SwingConstants.CENTER);
		studentsReports.setBounds(42, 10, 566, 30);
		frame1.add(studentsReports);
		
		viewAll = new JButton("View All Courses");
		viewAll.setForeground(new Color(148, 0, 211));
		viewAll.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		viewAll.setBackground(new Color(0, 0, 0));
		viewAll.setBounds(6, 55, 638, 50);
		viewAll.addActionListener(this);
		frame1.add(viewAll);
		
		viewFull = new JButton("View Courses That Are Not Full");
		viewFull.setForeground(new Color(148, 0, 211));
		viewFull.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		viewFull.setBackground(new Color(0, 0, 0));
		viewFull.setBounds(6, 105, 638, 50);
		viewFull.addActionListener(this);
		frame1.add(viewFull);
		
		register = new JButton("Register on a Course");
		register.setForeground(new Color(148, 0, 211));
		register.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		register.setBackground(new Color(0, 0, 0));
		register.setBounds(6, 155, 638, 50);
		register.addActionListener(this);
		frame1.add(register);
		
		withdraw = new JButton("Withdraw From A Course");
		withdraw.setForeground(new Color(148, 0, 211));
		withdraw.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		withdraw.setBackground(new Color(0, 0, 0));
		withdraw.setBounds(6, 205, 638, 50);
		withdraw.addActionListener(this);
		frame1.add(withdraw);
		
		studsCourse = new JButton("View All the Courses You Are Registered In");
		studsCourse.setForeground(new Color(148, 0, 211));
		studsCourse.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		studsCourse.setBackground(new Color(0, 0, 0));
		studsCourse.setBounds(6, 255, 638, 50);
		studsCourse.addActionListener(this);
		frame1.add(studsCourse);
		
		exit = new JButton("Exit");
		exit.setForeground(new Color(148, 0, 211));
		exit.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		exit.setBackground(new Color(0, 0, 0));
		exit.setBounds(6, 305, 638, 50);
		exit.addActionListener(this);
		frame1.add(exit);
			
			
			
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == viewAll) {
			/*
			 * View all method
			 */
			frame1.dispose();
			coursesToTable ctt = new coursesToTable("Viewing All Courses:",myGUI.us.viewAllCourses(), "Student", stud);
			
			
		}
		else if(e.getSource() == viewFull) {
			System.out.println("View Full");
			/*
			 * View full method
			 */
			frame1.dispose();
			coursesToTable ctt = new coursesToTable("Viewing Not Full Courses:",stud.viewFullCourses(),"Student", stud);
			
		}
		
		else if(e.getSource() == register) {
			System.out.println("Register");
			
			frame1.dispose();
			Object[][] course = new Object[myGUI.us.getCourse().size()][3];
			int i = 0;
			for(Courses c : myGUI.us.getCourse()) {
				course[i][0] = c.getCourseName();
				course[i][1] = c.getCourseID();
				course[i][2] = c.getCourseNum();
				i++;
			}
			coursesToTable_Button ctt = new coursesToTable_Button("Listing the Courses:",course,"Student", "Register", stud);//Object[] course = my
		
		}
		else if(e.getSource() == withdraw) {
			System.out.println("Withdraw");

			
			Object[][] studsC = stud.viewMyCourses();
			frame1.dispose();
			coursesToTable_Button ctt = new coursesToTable_Button("Listing Your Courses:",studsC,"Student","Withdraw", stud);//Object[] course = my
			
		}
		else if(e.getSource() == studsCourse) {
			Object[][] studsC = stud.viewMyCourses();
			System.out.println("studsCourse");
			frame1.dispose();
			coursesToTable ctl = new coursesToTable(stud.getFirstName() + " " + stud.getLastName() + "'s Courses: ",studsC,"Student", stud);//Object[] course = my
			
		}
		else if(e.getSource() == exit) {
			myGUI.us.exit();
			System.out.println("exit");
			/*
			 * exit
			 */
		}
		
		
		
		
		
		
	}
	
	

}




