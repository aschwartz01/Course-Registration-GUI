package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import schwartz.COURSES.Courses;
import schwartz.PEOPLE.Student;

public class adminMethods implements ActionListener {
	
	JFrame frame;
	JLabel adminsReports;
	JButton viewAll;
	JButton viewFull;
	JButton writeFull;
	JButton studsInCourse;
	JButton studsCourse;
	JButton sort;
	JLabel adminsMethods;
	JButton newCourse;
	JButton deleteCourse;
	JButton editCourse;
	JButton displayCourseInfo;
	JButton registerStud;
	JButton exit;
	JTable table1;
	JScrollPane jsp1;
	
	public adminMethods() {
		frame = new JFrame();
		frame.setBounds(120, 700, 650, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);
		
		adminsReports = new JLabel("****Admin's Reports****");
		adminsReports.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		adminsReports.setHorizontalAlignment(SwingConstants.CENTER);
		adminsReports.setBounds(42, 10, 566, 30);
		frame.add(adminsReports);
		
		viewAll = new JButton("View All Courses");
		viewAll.setForeground(new Color(148, 0, 211));
		viewAll.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		viewAll.setBackground(new Color(0, 0, 0));
		viewAll.setBounds(6, 55, 638, 50);
		viewAll.addActionListener(this);
		frame.add(viewAll);
		
		viewFull = new JButton("View Full Courses");
		viewFull.setForeground(new Color(148, 0, 211));
		viewFull.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		viewFull.setBackground(new Color(0, 0, 0));
		viewFull.setBounds(6, 105, 638, 50);
		viewFull.addActionListener(this);
		frame.add(viewFull);
		
		writeFull = new JButton("Write Full Courses");
		writeFull.setForeground(new Color(148, 0, 211));
		writeFull.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		writeFull.setBackground(new Color(0, 0, 0));
		writeFull.setBounds(6, 155, 638, 50);
		writeFull.addActionListener(this);
		frame.add(writeFull);
		
		studsInCourse = new JButton("View All the Students in a Specific Course");
		studsInCourse.setForeground(new Color(148, 0, 211));
		studsInCourse.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		studsInCourse.setBackground(new Color(0, 0, 0));
		studsInCourse.setBounds(6, 205, 638, 50);
		studsInCourse.addActionListener(this);
		frame.add(studsInCourse);
		
		studsCourse = new JButton("View All the Courses a Specific Student is Registered In");
		studsCourse.setForeground(new Color(148, 0, 211));
		studsCourse.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		studsCourse.setBackground(new Color(0, 0, 0));
		studsCourse.setBounds(6, 255, 638, 50);
		studsCourse.addActionListener(this);
		frame.add(studsCourse);
		
		sort = new JButton("Sort the Courses Based on the Number of Students Registered");
		sort.setForeground(new Color(148, 0, 211));
		sort.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		sort.setBackground(new Color(0, 0, 0));
		sort.setBounds(6, 305, 638, 50);
		sort.addActionListener(this);
		frame.add(sort);
		
		adminsMethods = new JLabel("****Admin's Methods****");
		adminsMethods.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		adminsMethods.setHorizontalAlignment(SwingConstants.CENTER);
		adminsMethods.setBounds(42, 360, 566, 30);
		frame.add(adminsMethods);
		
		newCourse = new JButton("Create a New Course");
		newCourse.setForeground(new Color(148, 0, 211));
		newCourse.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		newCourse.setBackground(new Color(0, 0, 0));
		newCourse.setBounds(6, 405, 638, 50);
		newCourse.addActionListener(this);
		frame.add(newCourse);
		
		deleteCourse = new JButton("Delete a Course");
		deleteCourse.setForeground(new Color(148, 0, 211));
		deleteCourse.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		deleteCourse.setBackground(new Color(0, 0, 0));
		deleteCourse.setBounds(6, 455, 638, 50);
		deleteCourse.addActionListener(this);
		frame.add(deleteCourse);
		
		editCourse = new JButton("Edit a Course");
		editCourse.setForeground(new Color(148, 0, 211));
		editCourse.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		editCourse.setBackground(new Color(0, 0, 0));
		editCourse.setBounds(6, 505, 638, 50);
		editCourse.addActionListener(this);
		frame.add(editCourse);
		
		displayCourseInfo = new JButton("Display a Courses Information");
		displayCourseInfo.setForeground(new Color(148, 0, 211));
		displayCourseInfo.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		displayCourseInfo.setBackground(new Color(0, 0, 0));
		displayCourseInfo.setBounds(6, 555, 638, 50);
		displayCourseInfo.addActionListener(this);
		frame.add(displayCourseInfo);
		
		registerStud = new JButton("Register a Student On a Course");
		registerStud.setForeground(new Color(148, 0, 211));
		registerStud.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		registerStud.setBackground(new Color(0, 0, 0));
		registerStud.setBounds(6, 605, 638, 50);
		registerStud.addActionListener(this);
		frame.add(registerStud);
		
		exit = new JButton("Exit");
		exit.setForeground(new Color(148, 0, 211));
		exit.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		exit.setBackground(new Color(0, 0, 0));
		exit.setBounds(6, 655, 638, 50);
		exit.addActionListener(this);
		frame.add(exit);
		frame.add(new JScrollPane());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == viewAll) {
			/*
			 * View all method
			 */
			frame.dispose();
			coursesToTable ctt = new coursesToTable("Viewing All Courses:",myGUI.us.viewAllCourses(),"Admin",null);
			
			
		}
		else if(e.getSource() == viewFull) {
			System.out.println("View Full");
			/*
			 * View full method
			 */
			frame.dispose();
			coursesToTable ctt = new coursesToTable("Viewing Full Courses:",myGUI.us.viewFullCourses(),"Admin",null);
			
		}
		else if(e.getSource() == writeFull) {
			System.out.println("Write Full");
			/*
			 * Write full method
			 */
			
			try {
				myGUI.us.writeFullCourses();

			}
			catch(Exception e1) {
				e1.printStackTrace();
			}
			
			
		}
		else if(e.getSource() == studsInCourse) {
			System.out.println("studsInCourse");
			/*
			 * studentsInACourse Method
			 */
			frame.dispose();
			Object[][] course = new Object[myGUI.us.getCourse().size()][3];
			int i = 0;
			for(Courses c : myGUI.us.getCourse()) {
				course[i][0] = c.getCourseName();
				course[i][1] = c.getCourseID();
				course[i][2] = c.getCourseNum();
				i++;
			}
			coursesToTable_Button ctt = new coursesToTable_Button("Listing the Courses:",course,"Admin", "studsInCourse", null);//Object[] course = my
			
			
		}
		else if(e.getSource() == studsCourse) {
			System.out.println("studsCourse");
			/*
			 * Student's courses method
			 */
			frame.dispose();
			Object[] course = new Object[myGUI.us.getStudent().size()];
			int i = 0;
			for(Student c : myGUI.us.getStudent()) {
				course[i] = (i+1) + ". " + c.getFirstName() + " " + c.getLastName(); ;
				i++;
			}
			studentsCoursesButton ctt = new studentsCoursesButton("Which student's courses would you like to view?",course);
			
		}
		else if(e.getSource() == sort) {
			System.out.println("sort");
			/*
			 * sort method
			 */
			myGUI.us.sort();
			frame.dispose();
			adminMethods a = new adminMethods();
			
		}
		else if(e.getSource() == newCourse) {
			System.out.println("newCourse");
			/*
			 * create a new course method
			 */
			frame.dispose();
			createNewCourse cnc = new createNewCourse();
		}
		else if(e.getSource() == deleteCourse) {
			System.out.println("deleteCourse");
			/*
			 * delete a course method
			 */
			frame.dispose();
			Object[][] course = new Object[myGUI.us.getCourse().size()][3];
			int i = 0;
			for(Courses c : myGUI.us.getCourse()) {
				course[i][0] = c.getCourseName();
				course[i][1] = c.getCourseID();
				course[i][2] = c.getCourseNum();
				i++;
			}
			coursesToTable_Button ctt = new coursesToTable_Button("Which course would you like to delete?",course,"Admin", "deleteCourse",null);//Object[] course = my
		}
		else if(e.getSource() == editCourse) {
			/*
			 * edit a course method
			 */
			System.out.println("editCourse");
			frame.dispose();
			Object[][] course = new Object[myGUI.us.getCourse().size()][4];
			int i = 0;
			for(Courses c : myGUI.us.getCourse()) {
				
				course[i][0] = c.getCourseName();
				course[i][1] = c.getCourseID();
				course[i][2] = c.getCourseNum();
				
				i++;
			}
			coursesToTable_Button ctt = new coursesToTable_Button("Which course would you like to edit?",course,"Admin", "editCourse",null);
			
			
		}
		else if(e.getSource() == displayCourseInfo) {
			System.out.println("displayCourseInfo");
			/*
			 * display a course's info
			 */
			frame.dispose();
			Object[][] course = new Object[myGUI.us.getCourse().size()][3];
			int i = 0;
			for(Courses c : myGUI.us.getCourse()) {
				course[i][0] = c.getCourseName();
				course[i][1] = c.getCourseID();
				course[i][2] = c.getCourseNum();
				i++;
			}
			coursesToTable_Button ctt = new coursesToTable_Button("Listing the Courses:",course,"Admin", "displayCourseInfo",null);//Object[] course = my
		}
		else if(e.getSource() == registerStud) {
			/*
			 * register a student
			 */
			System.out.println("registerStud");
			
			frame.dispose();
			Object[][] course = new Object[myGUI.us.getCourse().size()][5];
			int i = 0;
			for(Courses c : myGUI.us.getCourse()) {
				
				course[i][0] = c.getCourseName();
				course[i][1] = c.getCourseID();
				course[i][2] = c.getMaxStudents();
				course[i][3] = c.getNumRegStudents();
				course[i][4] = c.getCourseNum();
				
				i++;
			}
			
			coursesToTable_Register ctt = new coursesToTable_Register("Which Course Would You Like to Register a Student On?",course,"Admin", "registerStud");//Object[] course = my
		}
		
		else if(e.getSource() == exit) {
			/*
			 * exit
			 */
			myGUI.us.exit();
			System.out.println("exit");
			
		}
		
		
		
		
		
	}
	
	

}




