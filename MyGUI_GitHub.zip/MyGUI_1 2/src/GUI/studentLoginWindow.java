package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import schwartz.PEOPLE.Student;

public class studentLoginWindow implements ActionListener{
	
	JFrame frame;
	JLabel uLabel = new JLabel("Username:");
	JLabel pLabel = new JLabel("Password:");
	JTextField unameText;
	JTextField pwordText;
	JButton enterU;
	JButton enterP;
	InputHandler uHandler = new InputHandler();
	InputHandler pHandler = new InputHandler();
	JLabel message = new JLabel();
	String uname ;
	String pword;
	JLabel req;
	static Student s = null;
	
	//why does it open three extra super JFrames
	
	
	public studentLoginWindow(){
		
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);
		
		req = new JLabel("Enter your username and password: ");
		req.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req.setHorizontalAlignment(SwingConstants.CENTER);
		req.setBounds(42, 10, 566, 30);
		frame.add(req);
		
		JLabel unameLabel = new JLabel("Username:");
		unameLabel.setBounds(6, 50, 183, 81);
		
		
		JLabel pwordLabel = new JLabel("Password:");
		pwordLabel.setBounds(6, 135, 183, 81);
		
		frame.add(unameLabel);
		frame.add(pwordLabel);
		
		unameText = new JTextField();
		unameText.setBounds(180, 50, 183, 81);
		JButton enterU = new JButton("Enter");
		enterU.setForeground(new Color(148, 0, 211));
		enterU.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterU.setBackground(new Color(0, 0, 0));
		enterU.setBounds(370, 25, 183, 81);
		enterU.addActionListener(uHandler);
		
		
		pwordText = new JPasswordField();
		pwordText.setBounds(180, 135, 183, 81);
		JButton enterP = new JButton("Enter");
		enterP.setForeground(new Color(148, 0, 211));
		enterP.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterP.setBackground(new Color(0, 0, 0));
		enterP.setBounds(370, 135, 183, 81);
		enterP.addActionListener(pHandler);
		frame.add(enterP);
		
		
		frame.add(unameText);
		frame.add(pwordText);
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 200, 412, 81);
		
		frame.add(message);
		
	}
	
	public void addToFrame(int n, String fn, String ln, Student i) {
		if(n == 1) {
			message.setText("Welcome " + fn + " " + ln);
			/*
			 * Call the new Class making the new window with all the options of what the student can do
			 */
			frame.setVisible(false);
			frame.dispose();
			this.setS(i);
			studentMethods a = new studentMethods(i);
		}
		else if(n == 2) {
			message.setText("Incorrect Login Information. Goodbye");
		}
		else if(n == 3) {
			message.setText("There are no students currently registered. Please have the administrator register an account and then you will be able to log in");
		}
		else if(n == 4) {
			message.setText("No student can be found with that username");
		}
	}
	
	
	public class InputHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Hello");
			String utext = unameText.getText();
			String ptext = pwordText.getText();
			if(myGUI.us.getStudent().size() == 0) {
				addToFrame(3,"","",null);
			}
			Student stud = null;
			boolean tf = false;
			for(Student i : myGUI.us.getStudent()) {
				if (utext.equals(i.getUsername())) {
					tf = true;
					if(ptext.equals(i.getPassword())) {
						stud = i;
						stud.setCourse(myGUI.us.getCourse());
						stud.viewAllCourses();
						addToFrame(1,i.getFirstName(),i.getLastName(),i);
					}
					else {
						System.out.println("Incorrect Login Information");
						addToFrame(2,"","",null);
						
					}
				}
			}
			if(!tf) {
				System.out.println("No student can be found with that username");
				addToFrame(4,"","",null);
			}
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	public Student getS() {
		return s;
	}

	public void setS(Student s) {
		this.s = s;
	}


}
