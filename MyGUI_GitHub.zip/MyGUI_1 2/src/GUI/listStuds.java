package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;


public class listStuds {
	JFrame frame;
	
	JTable table1;
	JScrollPane jsp1;
	DefaultTableModel dtm1;
	JTableHeader jth1;
	JPanel jp1;
	JButton rb;
	JButton mainMenu;
	
	static Object[][] data1;
	
	public listStuds(String label, Object[] data, String menu) {
		final Object[] data1 = data;
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp1 = new JPanel();
		frame.setVisible(true); 
		
		JLabel viewAll = new JLabel(label);
		viewAll.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		viewAll.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll.setBounds(6, 10, 588, 30);
		frame.getContentPane().add(viewAll, BorderLayout.NORTH);
		
		
		String s = "Course Name";
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Students",data);
		JTable table = new JTable(model);
		
		
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		JTableHeader header = table.getTableHeader();
		header.setBackground(new Color(148, 0, 211));
		header.setForeground(Color.white);
		
		
		jsp1 = new JScrollPane(table);
		jp1.add(jsp1);
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					if(menu.equals("Admin")) {
						frame.dispose();
						adminMethods a = new adminMethods();
					}
				}	
			}
		});
		
		jp1.setBounds(6, 50, 588, 600);
		frame.getContentPane().add(jp1, BorderLayout.CENTER);
		frame.setSize(600, 700);
	}
}
