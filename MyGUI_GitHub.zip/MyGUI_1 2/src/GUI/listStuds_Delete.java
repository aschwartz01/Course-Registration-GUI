package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;


public class listStuds_Delete {
	JFrame frame;
	//JTable table;
	JTable table1;
	JScrollPane jsp1;
	DefaultTableModel dtm1;
	JTableHeader jth1;
	JPanel jp1;
	JButton rb;
	JButton mainMenu;
	ListSelectionModel select;
	static Object[][] data1;
	JLabel message = new JLabel();
	JLabel message2 = new JLabel();
	
	public listStuds_Delete(String label, Object[] data, String menu, String cid, int cnum) {
		final Object[] data1 = data;
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jp1 = new JPanel();
		frame.setVisible(true); 
		
		JLabel viewAll = new JLabel(label);
		viewAll.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		viewAll.setHorizontalAlignment(SwingConstants.CENTER);
		viewAll.setBounds(6, 10, 588, 30);
		frame.getContentPane().add(viewAll, BorderLayout.NORTH);
		
		
		String s = "Course Name";
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Students",data);
		JTable table = new JTable(model);
		
		
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		JTableHeader header = table.getTableHeader();
		header.setBackground(new Color(148, 0, 211));
		header.setForeground(Color.white);
		
		
		jsp1 = new JScrollPane(table);
		jp1.add(jsp1);
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 500, 412, 81);
		frame.add(message);
		
		
		message2.setFont(new Font("Lucida Grande", Font.BOLD, 18));
		message2.setHorizontalAlignment(SwingConstants.CENTER);
		message2.setBounds(55, 525, 412, 81);
		frame.add(message2);
		
		select = table.getSelectionModel();
		select.addListSelectionListener(new ListSelectionListener() {


			@Override
			public void valueChanged(ListSelectionEvent e) {
				int row = select.getMinSelectionIndex();
				if(e.getValueIsAdjusting()) {
					
				
					String[] name = ((String)data[row]).split("[ ,]");
					
					String r = myGUI.us.editCourse(cid, cnum, "registered", name[3] + "-" + name[1],"remove");
					if(r.length() > 40) {
						String[] mess = r.split(" ");
						String s1 = "";
						String s2 = "";
						int count = 0;
						for(String i : mess) {
							if(count < (mess.length/2)+1) {
								s1 += i + " ";
							}
							else {
								s2 += i + " ";
							}
							count++;
						}
						message.setText(s1);
						message2.setText(s2);
					}
					else {
						message.setText(r);
					}
				}
			}
		});
		
		mainMenu = new JButton("Return to Menu");
		mainMenu.setForeground(new Color(148, 0, 211));
		mainMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		mainMenu.setBackground(new Color(0, 0, 0));
		mainMenu.setBounds(6, 247, 183, 81);
		frame.getContentPane().add(mainMenu, BorderLayout.SOUTH);
		mainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == mainMenu) {
					if(menu.equals("Admin")) {
						frame.dispose();
						adminMethods a = new adminMethods();
					}
					
				}	
			}
		});
		
		jp1.setBounds(6, 50, 588, 600);
		frame.getContentPane().add(jp1, BorderLayout.CENTER);
		frame.setSize(600, 700);
	}
}
