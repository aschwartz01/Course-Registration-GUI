package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class adminLoginWindow implements ActionListener{
	
	JFrame frame;
	JLabel uLabel = new JLabel("Username:");
	JLabel pLabel = new JLabel("Password:");
	JTextField unameText;
	JTextField pwordText;
	JButton enterU;
	JButton enterP;
	InputHandler uHandler = new InputHandler();
	InputHandler pHandler = new InputHandler();
	JLabel message = new JLabel();
	String uname ;
	String pword;
	JLabel req;
	
	public adminLoginWindow(){
		
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);
		
		req = new JLabel("Enter your username and password: ");
		req.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		req.setHorizontalAlignment(SwingConstants.CENTER);
		req.setBounds(42, 10, 566, 30);
		frame.add(req);
		
		JLabel unameLabel = new JLabel("Username:");
		unameLabel.setBounds(6, 50, 183, 81);
		
		
		JLabel pwordLabel = new JLabel("Password:");
		pwordLabel.setBounds(6, 135, 183, 81);
		
		frame.add(unameLabel);
		frame.add(pwordLabel);
		
		unameText = new JTextField();
		unameText.setBounds(180, 50, 183, 81);
		
		
		pwordText = new JPasswordField();
		pwordText.setBounds(180, 135, 183, 81);
		JButton enterP = new JButton("Enter");
		enterP.setForeground(new Color(148, 0, 211));
		enterP.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		enterP.setBackground(new Color(0, 0, 0));
		enterP.setBounds(370, 135, 183, 81);
		enterP.addActionListener(pHandler);
		frame.add(enterP);
		
		
		frame.add(unameText);
		frame.add(pwordText);
		
		
		message.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		message.setHorizontalAlignment(SwingConstants.CENTER);
		message.setBounds(55, 200, 412, 81);
		
		frame.add(message);
		
		
		
	}
	
	public void addToFrame(int n) {
		if(n == 1) {
			message.setText("Welcome " + myGUI.us.getFirstName() + " " + myGUI.us.getLastName());
			/*
			 * Call the new Class making the new window with all the options of what the admin can do
			 */
			frame.dispose();
			adminMethods a = new adminMethods();
		}
		else if(n == 2) {
			message.setText("Incorrect Login Information");
		}
		else if(n == 3) {
			message.setText("We don't have that Admin registered");
		}
	}
	
	
	public class InputHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String utext = unameText.getText();
			String ptext = pwordText.getText();
			if (utext.equals(myGUI.us.getUsername())) {
				if(ptext.equals(myGUI.us.getPassword())) {
					addToFrame(1);
				}
				else {
					addToFrame(2);
				}
			}
			else {
				addToFrame(3);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}


	

}
